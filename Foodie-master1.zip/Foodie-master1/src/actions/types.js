export const REGISTER_CUST = "REGISTER_CUST";
export const GET_ERRORS = "GET_ERRORS"; 