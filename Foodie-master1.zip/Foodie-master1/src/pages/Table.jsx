import React, { Component } from 'react'
import { Link } from 'react-router-dom';

export default class Table extends Component {
    render() {
        return (
                

<div id="wrapper">

    {/* Sidebar */}
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        {/* Sidebar - Brand */}
        <Link class="sidebar-brand d-flex align-items-center justify-content-center" to="index.html">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
        </Link> 

        {/* Divider */}
        <hr class="sidebar-divider my-0" />

        {/* Nav Item - Dashboard */}
        <li class="nav-item">
            <Link class="nav-link" to="index.html">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></Link> 
        </li>

        {/* Divider */}
        <hr class="sidebar-divider" />

        {/* Heading */}
        <div class="sidebar-heading">
            Interface
        </div>

        {/* Nav Item - Pages Collapse Menu */}
        <li class="nav-item">
            <Link class="nav-link collapsed" to="#" data-toggle="collapse" data-target="#collapseTwo"
                aria-expanded="true" aria-controls="collapseTwo">
                <i class="fas fa-fw fa-cog"></i>
                <span>Components</span>
            </Link> 
        </li>


        {/* Divider */}
        <hr class="sidebar-divider" />

        {/* Heading */}
        <div class="sidebar-heading">
            Addons
        </div>

        {/* Nav Item - Pages Collapse Menu */}
        <li class="nav-item">
            <Link class="nav-link collapsed" to="#" data-toggle="collapse" data-target="#collapsePages"
                aria-expanded="true" aria-controls="collapsePages">
                <i class="fas fa-fw fa-folder"></i>
                <span>Pages</span>
            </Link> 

        </li>


        {/* Nav Item - Tables */}
        <li class="nav-item active">
            <Link class="nav-link" to="tables.html">
                <i class="fas fa-fw fa-table"></i>
                <span>Tables</span></Link> 
        </li>

        {/* Divider */}
        <hr class="sidebar-divider d-none d-md-block" />

        {/* Sidebar Toggler (Sidebar) */}
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
    {/* End of Sidebar */}

    {/* Content Wrapper */}
    <div id="content-wrapper" class="d-flex flex-column">

        {/* Main Content */}
        <div id="content">

            {/* Topbar */}
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                {/* Sidebar Toggle (Topbar) */}
                <form class="form-inline">
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                </form>



            </nav>
            {/* End of Topbar */}

            {/* Begin Page Content */}
            <div class="container-fluid">

                {/* Page Heading */}
                <h1 class="h3 mb-2 text-gray-800">Table</h1>


                {/* DataTales Example */}
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Primary Customers</h6>
                    </div>
{/* 
                    <div class="card-body">

                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Position</th>
                                        <th>Office</th>
                                        <th>Age</th>
                                        <th>Start date</th>
                                        <th>Salary</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>

                    </div> */}

                </div>

            </div>
            
            {/* /.container-fluid */}

        </div>
        {/* End of Main Content */}
{/*  */}
        {/* Footer */}
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    
                {/* Copyright component */}
                
                </div>
            </div>
        </footer>
         {/* End of Footer */} 

    </div>



<Link class="scroll-to-top rounded" to="#page-top">
    <i class="fas fa-angle-up"></i>
</Link> 

            </div>

        );
    }
}
